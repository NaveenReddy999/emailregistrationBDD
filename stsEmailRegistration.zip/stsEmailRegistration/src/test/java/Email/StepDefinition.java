package Email;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import PageBean.PageFactoryEmail;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	
	private WebDriver driver;
	private PageFactoryEmail objpfe;
	
	@Given("^User is on email registeration page$")
	public void user_is_on_email_registeration_page() throws Throwable {
	   driver= new FirefoxDriver();
	   objpfe= new PageFactoryEmail(driver);
	   driver.get("file:///D:/Module%203/BDD%20for%20Full%20Stack/Demos/Lesson%205-HTML%20Pages/WorkingWithForms.html?txtUName=&txtPwd=&txtFN=&txtLN=&DtOB=&Email=&Address=&Phone=&submit=Submit");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
	    if(driver.getTitle().contentEquals("Email Registration Forms"))
	    {
	    	System.out.println("******Title Matched");
	    }
	    else
	    	System.out.println("****Title Not Matched");
	    
	    driver.close();
	}

	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page() throws Throwable {
	    String heading=driver.findElement(By.xpath("html/body/h1")).getText();
	  if(heading.contentEquals("Email Registration"))
	  {
		  System.out.println("****Heading Matched");
	  }
	  else
		  System.out.println("****Heading Not Matched");
	  driver.close();
	}

	@When("^user enters all the fields$")
	public void user_enters_all_the_fields() throws Throwable {
	    objpfe.setUname("naveenreddy");
	    objpfe.setPasswd("Naveen123");
	    objpfe.setCnfrmpwd("Naveen123");
	    objpfe.setFname("Naveen");
	    objpfe.setLname("Reddy");
	                     Thread.sleep(3000);
	    objpfe.setMale();
	    objpfe.setBirth("25th june");
	    objpfe.setEmail("Naveen@gmail.com");
	    objpfe.setAddrs("Kodad");
	    objpfe.setCity("Pune");
	                Thread.sleep(3000);
	    objpfe.setPhone("7661030546");
	    objpfe.setMusic();
	    objpfe.setReading();
	                 Thread.sleep(3000);
	}

	@Then("^submit the form$")
	public void submit_the_form() throws Throwable {
	    objpfe.setSubmt();
	    driver.close();
	}

	@When("^user enters wrong confirmation password and clicks the submit button$")
	public void user_enters_wrong_confirmation_password_and_clicks_the_submit_button() throws Throwable {
		objpfe.setPasswd("Naveen123");
	    objpfe.setCnfrmpwd("Naveen12");
	                     Thread.sleep(3000);
	    objpfe.setSubmt();
	               Thread.sleep(3000);
	}

	@Then("^display alert message$")
	public void display_alert_message() throws Throwable {
	   String str=driver.switchTo().alert().getText();
	   System.out.println(str);
		driver.switchTo().alert().accept();
                 		Thread.sleep(3000);
		driver.close();
	}

	@When("^user enters incorrect email format and clicks the submit button$")
	public void user_enters_incorrect_email_format_and_clicks_the_submit_button() throws Throwable {
		objpfe.setEmail("Naveen");
		              Thread.sleep(3000);
		objpfe.setSubmt();
		              Thread.sleep(3000);
	}

	@Then("^email alert message$")
	public void email_alert_message() throws Throwable {
	   System.out.println("Email Alert Message");
	   driver.close();
	}
	
	@When("^user clicks on reset button$")
	public void user_clicks_on_reset_button() throws Throwable {
	    objpfe.setReset();
	}

	@Then("^clear all details$")
	public void clear_all_details() throws Throwable {
	  System.out.println("resetted");
	  driver.close();
	}



}
