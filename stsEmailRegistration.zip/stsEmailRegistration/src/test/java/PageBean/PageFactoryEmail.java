package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PageFactoryEmail {
	
	WebDriver driver;
	
	@FindBy(id="txtUserName")
	@CacheLookup
	WebElement uname;
	
	@FindBy(name="txtPwd")
	@CacheLookup
	WebElement passwd;
	
	@FindBy(id="txtConfPassword")
	@CacheLookup
	WebElement cnfrmpwd;
	
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement fname;
	
	@FindBy(id="txtLastName")
	@CacheLookup
	WebElement lname;
	
	@FindBy(id="rbMale")
	@CacheLookup
	WebElement male;

	@FindBy(id="rbFemale")
	@CacheLookup
	WebElement female;
	
	@FindBy(id="DOB")
	@CacheLookup
	WebElement birth;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement email;
	
	@FindBy(id="txtAddress")
	@CacheLookup
	WebElement addrs;
	
	@FindBy(name="City")
	@CacheLookup
	WebElement city;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement phone;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[12]/td[2]/input[1]")
	@CacheLookup
	WebElement music;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[12]/td[2]/input[2]")
	@CacheLookup
	WebElement reading;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[12]/td[2]/input[3]")
	@CacheLookup
	WebElement movies;
	
	@FindBy(name="reset")
	@CacheLookup
	WebElement reset;
	
	@FindBy(name="submit")
	@CacheLookup
	WebElement submt;


	public PageFactoryEmail(WebDriver driver) {
		this.driver=driver;
	PageFactory.initElements(driver, this);
	}


	public void setUname(String pfname) {
		uname.sendKeys(pfname);
	}


	public void setPasswd(String pfpasswd) {
		passwd.sendKeys(pfpasswd);
	}


	public void setCnfrmpwd(String pfcnfrmpwd) {
		cnfrmpwd.sendKeys(pfcnfrmpwd);
	}


	public void setFname(String pffname) {
		fname.sendKeys(pffname);
	}


	public void setLname(String pflname) {
		lname.sendKeys(pflname);
	}


	public void setMale( ) {
		male.click();
	}


	public void setFemale() {
		female.click();
	}


	public void setBirth(String pfbirth) {
		birth.sendKeys(pfbirth);
	}


	public void setEmail(String pfemail) {
		email.sendKeys(pfemail);
	}


	public void setAddrs(String pfaddrs) {
		addrs.sendKeys(pfaddrs);
	}


	public void setCity(String pfcity) {
		new Select(city).selectByVisibleText(pfcity);
	}


	public void setPhone(String pfphone) {
		phone.sendKeys(pfphone);
	}


	public void setMusic() {
		music.click();
	}


	public void setReading() {
		reading.click();
	}


	public void setMovies() {
		movies.click();
	}


	public void setReset() {
		reset.click();
	}


	public void setSubmt() {
		submt.click();
	}
	
}
